Esta textura está hecha exclusivamente para GeraBox.

Puede ser tomada por otro servidor, siempre que estén
los créditos de ElmichiYT.

Por ejemplo, en un bot o en un bloque de mensajes
(Message Block).

© Copyright 2024 - 2025 GeraBox. Todos los derechos reservados